---
title: Home
description: "Welcome to the docki Github page"
draft: false
slug: home
---

## HOME

Welcome to the [**docki Github**](https://github.com/sboistel/docki) page

Go back to [**docki.io**](https://sboistel.github.io/docki/) page

What do U mean about **knowledge transfert** ?

Let's having fun, and ``#RTFM`` !

You should get plaisir into the nav bar on the left

{{% notice tip %}}

Add the search section as your search engine

{{% /notice %}}
